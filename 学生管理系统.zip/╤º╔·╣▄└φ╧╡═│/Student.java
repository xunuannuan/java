package ѧ������ϵͳ;

public class Student {
	String name;
	String xuehao;
	int age;
	String xinbie;
public void setname(String name) {
	this.name=name;
}
public String getname() {
	return name;
}
public void setxuehao(String xuehao) {
	this.xuehao=xuehao;
}
public String getxuehao() {
	return xuehao;
}
public void setage(int age) {
	this.age=age;
}
public int getage() {
	return age;
}
public void setxinbie(String xinbie) {
	this.xinbie=xinbie;
}
public String getxinbie() {
	return xinbie;
}
}
